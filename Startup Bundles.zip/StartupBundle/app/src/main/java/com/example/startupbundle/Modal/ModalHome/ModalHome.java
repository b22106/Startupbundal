package com.example.startupbundle.Modal.ModalHome;

public class ModalHome {
    int img_home;
    String text_home;

    public ModalHome(int img_home, String text_home) {
        this.img_home = img_home;
        this.text_home = text_home;
    }

    public int getImg_home() {
        return img_home;
    }

    public void setImg_home(int img_home) {
        this.img_home = img_home;
    }

    public String getText_home() {
        return text_home;
    }

    public void setText_home(String text_home) {
        this.text_home = text_home;
    }
}
