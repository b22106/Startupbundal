package com.example.startupbundle.Activity.HomeActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.startupbundle.Activity.LoginActivity.LoginActivity;
import com.example.startupbundle.Fragmernts.CaseeFragment.CaseeFragment;
import com.example.startupbundle.Fragmernts.HomeFragment.HomeFragment;
import com.example.startupbundle.Fragmernts.LikeFragment.LikeFragment;
import com.example.startupbundle.Fragmernts.LoginFragment.LoginFragment;
import com.example.startupbundle.Fragmernts.NotificationFragment.NotificationFragment;
import com.example.startupbundle.Fragmernts.ProfileFragment.ProfileFragment;
import com.example.startupbundle.Fragmernts.SettingFragment.SettingFragment;
import com.example.startupbundle.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;

public class HomeActivity extends AppCompatActivity implements NavigationBarView.OnItemSelectedListener, View.OnClickListener {
    private String value;
    private FrameLayout homeContainer;
    private BottomNavigationView bottomNavigation;
    //drower
    NavigationView navigationView_drawer;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawerLayout;
    FrameLayout mylayout;
    ViewGroup.MarginLayoutParams params;
    private static final String SELECTED_ITEM = "selected_item";
    private int mMenuItemSelected;
    //dialog box
    Button cancle_btn, sign_out_btn;
    private ImageView img_menu;
    private ImageView img_notification;
    public static TextView txt_HeadingName;

    private String resetpassval;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        Intent intent = getIntent();
        value = intent.getStringExtra("role");
        resetpassval = intent.getStringExtra("resetfragment");
        inti();
        listiner();

        if (resetpassval != null && resetpassval.equals("resetfragment")) {
            ProfileFragment profileFragment = new ProfileFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, profileFragment).commit();
            //bottom icon change
            bottomNavigation.getMenu().findItem(R.id.profile).setChecked(true);

        } else {
            HomeFragment homeFragment = new HomeFragment();
            Bundle bundle = new Bundle();
            bundle.putString("role", value);
            homeFragment.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, homeFragment).commit();
            mylayout = findViewById(R.id.homeContainer);
            params = (ViewGroup.MarginLayoutParams) mylayout.getLayoutParams();
        }

        navigationView_drawer.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {


                //Check to see which item was clicked and perform the appropriate action.
                switch (menuItem.getItemId()) {

                    case R.id.home_draw:
                        HomeFragment homeFragment = new HomeFragment();
                        getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, homeFragment).commit();
                        drawerLayout.close();
                        return true;
                    case R.id.setting_draw:
                        SettingFragment settingFragment = new SettingFragment();
                        Bundle bundle = new Bundle();
                        bundle.putString("role", value);
                        settingFragment.setArguments(bundle);
                        getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, settingFragment).commit();

//                        getSupportFragmentManager().beginTransaction().replace(android.R.id.content, new SettingFragment()).commit();
                        drawerLayout.close();

                        return true;
                    case R.id.privacy_policy_draw:

                        Uri uri2 = Uri.parse("https://blacktonature.club/eula"); // missing 'http://' will cause crashed
                        Intent intent2 = new Intent(Intent.ACTION_VIEW, uri2);
                        startActivity(intent2);
                        return true;
                    case R.id.condition_draw:

                        Uri uri3 = Uri.parse("https://blacktonature.club/eula"); // missing 'http://' will cause crashed
                        Intent intent3 = new Intent(Intent.ACTION_VIEW, uri3);
                        startActivity(intent3);
                        return true;
                    case R.id.logout_draw:

                        AlertDialog();

                }
                return true;
            }
        });

    }

    private void inti() {
        homeContainer = findViewById(R.id.homeContainer);
        bottomNavigation = findViewById(R.id.bottomNavigation);
        drawerLayout = findViewById(R.id.drawer);
        navigationView_drawer = findViewById(R.id.nav_menu);
        img_menu = findViewById(R.id.img_menu);
        img_notification = findViewById(R.id.img_notification);
        txt_HeadingName = findViewById(R.id.txt_HeadingName);

        toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

    }

    private void listiner() {
        bottomNavigation.setOnItemSelectedListener(this);
        img_menu.setOnClickListener(this);
        img_notification.setOnClickListener(this);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.nev_menu, menu);
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.home:
//               bottomNavigation.setVisibility(View.VISIBLE);
//               params.setMargins(0, 0, 0, 0);
                HomeFragment homeFragment = new HomeFragment();
                Bundle bundle = new Bundle();
                bundle.putString("role", value);
                homeFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, homeFragment).commit();
                return true;
            case R.id.like:
//                toolbar.setVisibility(View.GONE);
//                params.setMargins(0, 0, 0, 0);
//                mylayout.setLayoutParams(params);
                LikeFragment likeFragment = new LikeFragment();
                bundle = new Bundle();
                bundle.putString("role", value);
                likeFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, likeFragment).commit();
                return true;
            case R.id.casee:
//                toolbar.setVisibility(View.GONE);
//                params.setMargins(0, 0, 0, 0);
                CaseeFragment caseeFragment = new CaseeFragment();
                bundle = new Bundle();
                bundle.putString("role", value);
                caseeFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, caseeFragment).commit();
                return true;
            case R.id.profile:
//                toolbar.setVisibility(View.GONE);
//                params.setMargins(0, 0, 0, 0);
                ProfileFragment profileFragment = new ProfileFragment();
                bundle = new Bundle();
                bundle.putString("role", value);
                profileFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, profileFragment).commit();
                return true;


        }
        return false;
    }

    private void AlertDialog() {
        AlertDialog.Builder alert = new AlertDialog.Builder(HomeActivity.this);
        View mView = getLayoutInflater().inflate(R.layout.dialog_box_logout, null);
        alert.setView(mView);

        final AlertDialog alertDialog = alert.create();
        sign_out_btn = mView.findViewById(R.id.sign_out_btn);
        cancle_btn = mView.findViewById(R.id.cancle_btn);

        alertDialog.setCanceledOnTouchOutside(false);
        cancle_btn.setOnClickListener(view -> {
            alertDialog.dismiss();
        });

        sign_out_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });


        alertDialog.show();
    }

    //on backpress
    @Override
    public void onBackPressed() {
        BottomNavigationView mBottomNavigationView = findViewById(R.id.bottomNavigation);
        if (mBottomNavigationView.getSelectedItemId() == R.id.home) {
            super.onBackPressed();
            finish();
        } else {
            mBottomNavigationView.setSelectedItemId(R.id.home);
        }
    }

    @Override
    public void onClick(View v) {

        if (v == img_menu) {
            drawerLayout.open();
        } else if (v == img_notification) {
                NotificationFragment notificationFragment = new NotificationFragment();
                Bundle bundle = new Bundle();
                bundle.putString("role", value);
                notificationFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, notificationFragment).addToBackStack(null).commit();

                //bottom icon change
                bottomNavigation.getMenu().findItem(R.id.home).setChecked(true);




        }
    }
}



