package com.example.startupbundle.Modal.ModalLike;

public class ModalLike {
    int img_like;
    String text_like;

    public ModalLike(int img_like, String text_like) {
        this.img_like = img_like;
        this.text_like = text_like;
    }

    public int getImg_like() {
        return img_like;
    }

    public void setImg_like(int img_like) {
        this.img_like = img_like;
    }

    public String getText_like() {
        return text_like;
    }

    public void setText_like(String text_like) {
        this.text_like = text_like;
    }
}
