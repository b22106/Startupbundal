package com.example.startupbundle.Fragmernts.SettingFragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewTreeViewModelKt;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.startupbundle.Activity.HomeActivity.HomeActivity;
import com.example.startupbundle.R;


public class SettingFragment extends Fragment {
private View view;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view=inflater.inflate(R.layout.fragment_setting, container, false);
        HomeActivity.txt_HeadingName.setText("Setting");
        return view;

    }
}