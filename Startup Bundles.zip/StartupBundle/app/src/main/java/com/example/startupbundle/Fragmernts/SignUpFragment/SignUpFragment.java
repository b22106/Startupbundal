package com.example.startupbundle.Fragmernts.SignUpFragment;

import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.startupbundle.Fragmernts.LoginFragment.LoginFragment;
import com.example.startupbundle.R;


public class SignUpFragment extends Fragment implements View.OnClickListener {
    View view;
    private boolean flag = true;
    private EditText et_email,et_userName,et_signUpPassword, et_conPassword;
    private ImageView img_pass_show, img_con_pass_show;
    private TextView tv_backToLogin;
    private Button signUpBtn;
    private String email,username,password,conpassword;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_sign_up, container, false);
        inti();
        listiner();

        return view;
    }

    private void inti() {
        et_email=view.findViewById(R.id.et_email);
        et_userName=view.findViewById(R.id.et_userName);
        et_signUpPassword = view.findViewById(R.id.et_signUpPassword);
        et_conPassword = view.findViewById(R.id.et_conPassword);
        img_pass_show = view.findViewById(R.id.img_pass_show);
        img_con_pass_show = view.findViewById(R.id.img_con_pass_show);
        tv_backToLogin = view.findViewById(R.id.tv_backToLogin);
        signUpBtn = view.findViewById(R.id.signUpBtn);
    }

    private void listiner() {
        img_pass_show.setOnClickListener(this);
        img_con_pass_show.setOnClickListener(this);
        tv_backToLogin.setOnClickListener(this);
        signUpBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view == img_pass_show) {
            if (flag) {
                et_signUpPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                img_pass_show.setImageResource(R.drawable.eye_show);
                et_signUpPassword.setSelection(et_signUpPassword.getText().length());
            } else {
                et_signUpPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                img_pass_show.setImageResource(R.drawable.eyehide);
                et_signUpPassword.setSelection(et_signUpPassword.getText().length());
            }
            flag = !flag;
        } else if (view == img_con_pass_show) {
            if (flag) {
                et_conPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                img_con_pass_show.setImageResource(R.drawable.eye_show);
                et_conPassword.setSelection(et_conPassword.getText().length());
            } else {
                et_conPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                img_con_pass_show.setImageResource(R.drawable.eyehide);
                et_conPassword.setSelection(et_conPassword.getText().length());
            }
            flag = !flag;
        } else if (view == tv_backToLogin) {
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.mainContainer, new LoginFragment()).commit();
        } else if (view == signUpBtn) {
            email=et_email.getText().toString().trim();
            username=et_userName.getText().toString().trim();
            password=et_signUpPassword.getText().toString().trim();
            conpassword=et_conPassword.getText().toString().trim();
            if (email.isEmpty()){
                et_email.setError("Fill the Email");
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                et_email.setError("Please enter a valid email address");
            }else if (username.isEmpty()){
                et_userName.setError("Enter the name");
            }else if (password.isEmpty()){
                et_signUpPassword.setError("Enter the password");
            }else if (conpassword.isEmpty()){
                et_conPassword.setError("Enter the confirm password");
            }else if (!password.equals(conpassword)){
                et_conPassword.setError("not match");
            }else {
                LoginFragment loginFragment=new LoginFragment();
                Bundle bundle=new Bundle();
                bundle.putString("Email",email);
                bundle.putString("Pass",password);
                loginFragment.setArguments(bundle);
                requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.mainContainer, loginFragment).commit();

            }

        }
    }

}
