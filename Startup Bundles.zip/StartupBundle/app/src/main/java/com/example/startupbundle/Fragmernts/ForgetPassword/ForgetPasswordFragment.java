package com.example.startupbundle.Fragmernts.ForgetPassword;

import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;

import com.example.startupbundle.Fragmernts.LoginFragment.LoginFragment;
import com.example.startupbundle.Fragmernts.OtpFragment.OtpFragment;
import com.example.startupbundle.R;

import java.util.zip.Deflater;


public class ForgetPasswordFragment extends Fragment implements View.OnClickListener {
    private View view;
    private EditText et_email;
    private Button continueBtn;
    private ImageView img_back;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_forget_password, container, false);
        inti();
        listiner();
        return view;
    }

    private void inti() {
        et_email = view.findViewById(R.id.et_email);
        continueBtn = view.findViewById(R.id.continueBtn);
        img_back = view.findViewById(R.id.img_back);
    }

    private void listiner() {
        continueBtn.setOnClickListener(this);
        img_back.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view == continueBtn) {
            String email_id = et_email.getText().toString().trim();
            if (email_id.isEmpty()) {
                et_email.setError("first fill the email ");
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email_id).matches()) {
                    et_email.setError("Please enter a valid email address");
            }else {
                OtpFragment otpfragment = new OtpFragment();
                Bundle bundle = new Bundle();
                bundle.putString("key", email_id);
                bundle.putString("role","value");
                otpfragment.setArguments(bundle);
                requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.mainContainer, otpfragment).commit();
            }

        } else if (view == img_back) {

            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.mainContainer,new LoginFragment()).commit();
//            LoginFragment loginFragment = new LoginFragment();
//            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction().addToBackStack(null);
//            transaction.replace(R.id.mainContainer, loginFragment);
//            transaction.commit();


//            ((FragmentActivity) mContext).getFragmentManager().executePendingTransactions();


//            LoginFragment loginfragment = new LoginFragment();
////            Bundle bundle = new Bundle();
////            bundle.putString("role", value);
////            loginfragment.setArguments(bundle);
//            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.mainContainer, loginfragment).addToBackStack(null).commit();

        }

    }
}