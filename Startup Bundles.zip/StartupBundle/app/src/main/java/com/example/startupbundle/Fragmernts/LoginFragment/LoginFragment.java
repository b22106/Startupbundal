package com.example.startupbundle.Fragmernts.LoginFragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.startupbundle.Activity.HomeActivity.HomeActivity;
import com.example.startupbundle.Fragmernts.EditProfileFragment.EditProfileFragment;
import com.example.startupbundle.Fragmernts.ForgetPassword.ForgetPasswordFragment;
import com.example.startupbundle.Fragmernts.SignUpFragment.SignUpFragment;
import com.example.startupbundle.R;

import java.util.regex.Pattern;


public class LoginFragment extends Fragment implements View.OnClickListener {

    private String value;
    private String email_value, password_value;
    private TextView tv_createAcc;
    private TextView tv_forgotPass;
    private Button btn_continue;
    private boolean flag = true;
    private ImageView img_pass_show;
    private EditText et_email, et_password;
    private View view;
    private Activity activity;
    private String email, password;
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    //"(?=.*[0-9])" +         //at least 1 digit
                    //"(?=.*[a-z])" +         //at least 1 lower case letter
                    //"(?=.*[A-Z])" +         //at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +      //any letter
                    "(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +           //no white spaces
                    ".{4,}" +               //at least 4 characters
                    "$");

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_login, container, false);
        activity = getActivity();
        inti();
        listiner();
//        Bundle bundle = getArguments();
//        email_value = bundle.getString("Email", "email");
//        password_value = bundle.getString("Pass", "password");

        return view;

    }

    private void inti() {

        tv_createAcc = view.findViewById(R.id.tv_createAcc);
        tv_forgotPass = view.findViewById(R.id.tv_forgotPass);
        btn_continue = view.findViewById(R.id.btn_continue);
        img_pass_show = view.findViewById(R.id.img_pass_show);
        et_password = view.findViewById(R.id.et_password);
        et_email = view.findViewById(R.id.et_email);

    }

    private void listiner() {

        tv_createAcc.setOnClickListener(this);
        tv_forgotPass.setOnClickListener(this);
        btn_continue.setOnClickListener(this);
        img_pass_show.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        if (view == img_pass_show) {
            if (flag) {
                et_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                img_pass_show.setImageResource(R.drawable.eye_show);
                et_password.setSelection(et_password.getText().length());
            } else {
                et_password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                img_pass_show.setImageResource(R.drawable.eyehide);
                et_password.setSelection(et_password.getText().length());
            }
            flag = !flag;
        } else if (view == tv_createAcc) {
            SignUpFragment signUpFragment = new SignUpFragment();
            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction().addToBackStack(null);
            transaction.replace(R.id.mainContainer, signUpFragment);
            transaction.commit();
            // requireActivity().getSupportFragmentManager().beginTransaction().add(R.id.mainContainer, new SignUpFragment()).commit();

        } else if (view == btn_continue) {
            if (!validateEmail() | !validatePassword()) {
                return;
            }
                Intent intent = new Intent(getActivity(), HomeActivity.class);
                intent.putExtra("role", value);
                startActivity(intent);
                activity.finish();

            } else if (view == tv_forgotPass) {

                //  requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.mainContainer, new ForgetPasswordFragment()).addToBackStack(null).commit();

                ForgetPasswordFragment forgetPasswordFragment = new ForgetPasswordFragment();
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction().addToBackStack(null);
                transaction.replace(R.id.mainContainer, forgetPasswordFragment);
                transaction.commit();

//
//            ForgetPasswordFragment forgetPasswordFragment = new ForgetPasswordFragment();
////            Bundle bundle = new Bundle();
////            bundle.putString("role", value);
////            forgetPasswordFragment.setArguments(bundle);
//

            }

        }

        private boolean validateEmail () {
            email = et_email.getText().toString().trim();
            if (email.isEmpty()) {
                et_email.setError("Field can't be empty");
                return false;
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                et_email.setError("Please enter a valid email address");
                return false;
            } else {
                et_email.setError(null);
                return true;
            }
        }

        private boolean validatePassword () {
            password = et_password.getText().toString().trim();

            if (password.isEmpty()) {
                et_password.setError("Field can't be empty");
                return false;
            } else if (!PASSWORD_PATTERN.matcher(password).matches()) {
                et_password.setError("Password too weak");
                return false;
            } else {
                et_password.setError(null);
                return true;
            }
        }
    }


