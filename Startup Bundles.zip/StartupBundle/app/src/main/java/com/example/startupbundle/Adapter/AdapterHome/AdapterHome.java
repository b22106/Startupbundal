package com.example.startupbundle.Adapter.AdapterHome;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.startupbundle.Fragmernts.HomeFragment.HomeFragment;
import com.example.startupbundle.Modal.ModalHome.ModalHome;
import com.example.startupbundle.R;

import java.util.ArrayList;

public class AdapterHome extends RecyclerView.Adapter<AdapterHome.viewholder> {
    private View view;
    HomeFragment context_home;
    ArrayList<ModalHome> listhome;

    public AdapterHome(ArrayList<ModalHome> listhome, HomeFragment context_home) {
        this.listhome = listhome;
        this.context_home = context_home;
    }

    @NonNull
    @Override
    public AdapterHome.viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_recycler, parent, false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterHome.viewholder holder, int position) {
        holder.img_home.setImageResource(listhome.get(position).getImg_home());
        holder.text_home.setText(listhome.get(position).getText_home());
    }

    @Override
    public int getItemCount() {
        return listhome.size();
    }

    public class viewholder extends RecyclerView.ViewHolder {
        ImageView img_home;
        TextView text_home;

        public viewholder(@NonNull View itemView) {
            super(itemView);
            img_home = itemView.findViewById(R.id.img_home);
            text_home = itemView.findViewById(R.id.text_home);
        }
    }
}
