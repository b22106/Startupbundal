package com.example.startupbundle.Fragmernts.EditProfileFragment;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.startupbundle.Activity.HomeActivity.HomeActivity;
import com.example.startupbundle.Adapter.CustomAdapter;
import com.example.startupbundle.Fragmernts.LoginFragment.LoginFragment;
import com.example.startupbundle.Fragmernts.NotificationFragment.NotificationFragment;
import com.example.startupbundle.Fragmernts.ProfileFragment.ProfileFragment;
import com.example.startupbundle.Fragmernts.ResetPassword.ResetPasswordFragment;
import com.example.startupbundle.R;


public class EditProfileFragment extends Fragment implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    private View view;
    private EditText fullName, email, mobile;
    private ImageView img_back_editprofile, img_notification_editprofile, img_menu;
    private ImageView img_editProfile;
    private Spinner spinner_gender;
    private Button btn_saveChanges;
    private String value,value2;
    private String[] gender = {"","Male", "Female", "TransGender"};
    private int[] gender1 = {0, 1, 2};
    private String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    private int SELECT_PICTURE = 200;
    private ImageView civ_profile;
    private TextView change_password;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_editprofile_fragment, container, false);
        inti();
        listiner();


        //Getting the instance of Spinner and applying OnItemSelectedListener on it
        Spinner spin = view.findViewById(R.id.simpleSpinner);
        spin.setOnItemSelectedListener(this);

        CustomAdapter customAdapter = new CustomAdapter(getActivity(), gender1, gender);
        spin.setAdapter(customAdapter);

//        ArrayAdapter cc = new ArrayAdapter(getContext(), android.R.layout.simple_spinner_item, gender);
//        cc.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spinner_gender.setAdapter(cc);


//        ArrayAdapter aa = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_item, gender);
//        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spinner_gender.setAdapter(aa);


        HomeActivity.txt_HeadingName.setText("Edit Profile");
        Bundle bundle = getArguments();
        value = bundle.getString("role");


        return view;
    }

    private void inti() {
        btn_saveChanges = view.findViewById(R.id.btn_saveChanges);
        fullName = view.findViewById(R.id.et_fullName);
        email = view.findViewById(R.id.et_email);
        change_password = view.findViewById(R.id.change_password);
        mobile = view.findViewById(R.id.et_mobile);
        img_editProfile = view.findViewById(R.id.img_editProfile);
        civ_profile = view.findViewById(R.id.civ_profile);

    }

    private void listiner() {
        btn_saveChanges.setOnClickListener(this);
        img_editProfile.setOnClickListener(this);
        change_password.setOnClickListener(this);
        //  spinner_gender.setOnItemSelectedListener(this);

    }

    @Override
    public void onClick(View view) {
        if (view == img_back_editprofile) {

            ProfileFragment profileFragment = new ProfileFragment();
            Bundle bundle = new Bundle();
            bundle.putString("role", value);
            profileFragment.setArguments(bundle);
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, profileFragment).addToBackStack(null).commit();
        } else if (view == btn_saveChanges) {
            EditProfile();


        } else if (view == img_notification_editprofile) {

            NotificationFragment notificationFragment = new NotificationFragment();
            Bundle bundle = new Bundle();
            bundle.putString("role", value);
            notificationFragment.setArguments(bundle);
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, notificationFragment).addToBackStack(null).commit();

        } else if (view == img_editProfile) {
            imageChooser();
        } else if (view == change_password) {

//            Bundle bundle = new Bundle();
//            bundle.putString("role2", "value2");
//
//            ResetPasswordFragment resetPasswordFragment = new ResetPasswordFragment();
//            resetPasswordFragment.setArguments(bundle);
//
//            getFragmentManager()
//                    .beginTransaction()
//                    .replace(android.R.id.content, resetPasswordFragment)
//                    .commit();


            ResetPasswordFragment resetPasswordFragment = new ResetPasswordFragment();
            Bundle bundle = new Bundle();
            bundle.putString("role2", value2);
            resetPasswordFragment.setArguments(bundle);
            requireActivity().getSupportFragmentManager().beginTransaction().replace(android.R.id.content, resetPasswordFragment).commit();

        }

    }

    private void imageChooser() {
        Intent i = new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);

        // pass the constant to compare it
        // with the returned requestCode
        startActivityForResult(Intent.createChooser(i, "Select Picture"), SELECT_PICTURE);

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {


            if (requestCode == SELECT_PICTURE) {
                // Get the url of the image from data
                Uri selectedImageUri = data.getData();
                if (null != selectedImageUri) {
                    // update the preview image in the layout
                    civ_profile.setImageURI(selectedImageUri);
                }
            }
        }
    }

    private void EditProfile() {
        String et_fullName = fullName.getText().toString().trim();
        String et_email = email.getText().toString().trim();
        String et_mobile = mobile.getText().toString().trim();
        if (et_fullName.isEmpty()) {
            fullName.setError("Enter Your Name");
        } else if (et_email.matches(emailPattern)) {
            email.setError("Enter your Email");
        } else if (et_mobile.isEmpty()) {
            mobile.setError("Enter the mobile number");
        } else {
            ProfileFragment profileFragment = new ProfileFragment();
            Bundle bundle = new Bundle();
            bundle.putString("fullName", "fullName");
            bundle.putString("email", "email");
            bundle.putString("mobile", "mobile");
            bundle.putString("role", value);
            profileFragment.setArguments(bundle);
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, profileFragment).addToBackStack(null).commit();
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//        ((TextView) parent.getChildAt(0)).setTextColor(R.color.app_color);
//        ((TextView) parent.getChildAt(0)).setTextSize(16);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}