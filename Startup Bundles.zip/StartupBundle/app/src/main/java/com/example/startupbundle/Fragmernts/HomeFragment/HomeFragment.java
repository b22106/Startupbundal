package com.example.startupbundle.Fragmernts.HomeFragment;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import com.example.startupbundle.Activity.HomeActivity.HomeActivity;
import com.example.startupbundle.Adapter.AdapterHome.AdapterHome;
import com.example.startupbundle.Adapter.viewpager.ViewPagerAdapter;
import com.example.startupbundle.Modal.ModalHome.ModalHome;
import com.example.startupbundle.R;
import com.tbuonomo.viewpagerdotsindicator.DotsIndicator;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import me.relex.circleindicator.CircleIndicator;


public class HomeFragment extends Fragment implements View.OnClickListener {
    int ci = 0;
    java.util.Timer timer;
    private Handler handler;
    private ViewPager viewpager_home;
    private View view;
    private CircleIndicator indicator;
    //    private DotsIndicator dotsIndicator;
    //recycler
    private RecyclerView home_recycler;
    private AdapterHome adapterHome;
    private ArrayList<ModalHome> listhome;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);
        inti();
        listiner();

        HomeActivity.txt_HeadingName.setText("Home");
        return view;
    }

    private void inti() {
        viewpager_home = view.findViewById(R.id.viewpager_home);
        indicator = view.findViewById(R.id.indicator);
        home_recycler = view.findViewById(R.id.home_recycler);
        List<Integer> imagelist = new ArrayList<>();
        imagelist.add(R.drawable.v1);
        imagelist.add(R.drawable.v2);
        imagelist.add(R.drawable.v3);
        imagelist.add(R.drawable.v4);
        imagelist.add(R.drawable.v5);
        imagelist.add(R.drawable.v6);
        imagelist.add(R.drawable.v7);
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(imagelist);
        viewpager_home.setAdapter(viewPagerAdapter);
        indicator.setViewPager(viewpager_home);
        handler = new Handler();
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        int i = viewpager_home.getCurrentItem();
                        if (i == imagelist.size() - 1) {
                            i = 0;
                            viewpager_home.setCurrentItem(i, true);
                        } else {
                            i++;
                            viewpager_home.setCurrentItem(i, true);
                        }

                    }
                });
            }

        }, 2000, 2000);


        listhome = new ArrayList<>();
        listhome.add(new ModalHome(R.drawable.legesy1, "legasy"));
        listhome.add(new ModalHome(R.drawable.legesy1, "legasy"));
        listhome.add(new ModalHome(R.drawable.legesy1, "legasy"));


        adapterHome = new AdapterHome(listhome, this);
        home_recycler.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        home_recycler.setAdapter(adapterHome);


    }


    private void listiner() {
//        legacy1_home.setOnClickListener(this);
//        legacy2_home.setOnClickListener(this);
//        legacy3_home.setOnClickListener(this);
//        legacy4_home.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
//        if (view == legacy1_home) {
//            Toast.makeText(getContext(), "legacy1", Toast.LENGTH_SHORT).show();
//        } else if (view == legacy2_home) {
//            Toast.makeText(getContext(), "legacy2", Toast.LENGTH_SHORT).show();
//        } else if (view == legacy3_home) {
//            Toast.makeText(getContext(), "legacy3", Toast.LENGTH_SHORT).show();
//        } else if (view == legacy4_home) {
//            Toast.makeText(getContext(), "legacy4", Toast.LENGTH_SHORT).show();
//        }


    }

}