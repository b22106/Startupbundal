package com.example.startupbundle.Adapter.AdapterLike;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.startupbundle.Fragmernts.LikeFragment.LikeFragment;
import com.example.startupbundle.Modal.ModalLike.ModalLike;
import com.example.startupbundle.R;

import java.util.ArrayList;

public class AdapterLike extends RecyclerView.Adapter<AdapterLike.viewholder> {
    private ArrayList<ModalLike> listlike;
    private LikeFragment context;
    private View view;

    public AdapterLike(ArrayList<ModalLike> listlike, LikeFragment context) {
        this.listlike = listlike;
        this.context = context;
    }

    @NonNull
    @Override
    public AdapterLike.viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.like_recycler, parent, false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterLike.viewholder holder, int position) {
        holder.img_like.setImageResource(listlike.get(position).getImg_like());
        holder.text_like.setText(listlike.get(position).getText_like());
    }

    @Override
    public int getItemCount() {
        return listlike.size();
    }

    public class viewholder extends RecyclerView.ViewHolder {
        ImageView img_like;
        TextView text_like;

        public viewholder(@NonNull View itemView) {
            super(itemView);
            img_like = itemView.findViewById(R.id.img_like);
            text_like = itemView.findViewById(R.id.text_like);
        }
    }
}
