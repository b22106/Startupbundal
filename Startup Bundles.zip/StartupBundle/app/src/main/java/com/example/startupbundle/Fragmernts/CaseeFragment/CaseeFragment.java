package com.example.startupbundle.Fragmernts.CaseeFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.example.startupbundle.Activity.HomeActivity.HomeActivity;
import com.example.startupbundle.R;


public class CaseeFragment extends Fragment {
private View view;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view= inflater.inflate(R.layout.fragment_casee, container, false);
        HomeActivity.txt_HeadingName.setText("Casee");
        return   view;
    }
}