package com.example.startupbundle.Fragmernts.LikeFragment;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import com.example.startupbundle.Activity.HomeActivity.HomeActivity;
import com.example.startupbundle.Adapter.AdapterLike.AdapterLike;
import com.example.startupbundle.Adapter.Viewpager_like.ViewPagerAdapter_like;
import com.example.startupbundle.Adapter.viewpager.ViewPagerAdapter;
import com.example.startupbundle.Modal.ModalLike.ModalLike;
import com.example.startupbundle.R;
import com.tbuonomo.viewpagerdotsindicator.DotsIndicator;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import me.relex.circleindicator.CircleIndicator;


public class LikeFragment extends Fragment implements View.OnClickListener {
    int ci = 0;
    java.util.Timer timer;
    private Handler handler;
    private ViewPager viewpager_Like;
    private View view;
    private CircleIndicator indicator_like;
    //
    private RecyclerView like_recycler;
    private AdapterLike adapterLike;
    private ArrayList<ModalLike> listlike;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_like, container, false);

        HomeActivity.txt_HeadingName.setText("Favourite");
        inti();
        listiner();
        return view;
    }

    private void inti() {
        viewpager_Like = view.findViewById(R.id.viewpager_Like);
        like_recycler = view.findViewById(R.id.like_recycler);

        indicator_like = view.findViewById(R.id.indicator);
        List<Integer> imagelist_like = new ArrayList<>();
        imagelist_like.add(R.drawable.v1);
        imagelist_like.add(R.drawable.v2);
        imagelist_like.add(R.drawable.v3);
        imagelist_like.add(R.drawable.v4);
        imagelist_like.add(R.drawable.v5);
        imagelist_like.add(R.drawable.v6);
        imagelist_like.add(R.drawable.v7);

        ViewPagerAdapter_like viewPagerAdapter_like = new ViewPagerAdapter_like(imagelist_like);
        viewpager_Like.setAdapter(viewPagerAdapter_like);
        indicator_like.setViewPager(viewpager_Like);
        handler = new Handler();
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        int i = viewpager_Like.getCurrentItem();
                        if (i == imagelist_like.size() - 1) {
                            i = 0;
                            viewpager_Like.setCurrentItem(i, true);

                        } else {
                            i++;
                            viewpager_Like.setCurrentItem(i, true);
                        }
                    }
                });
            }

        }, 2000, 2000);

        listlike = new ArrayList<>();
        listlike.add(new ModalLike(R.drawable.legasy_like1, "legasy"));
        listlike.add(new ModalLike(R.drawable.legasy_like1, "legasy"));
        listlike.add(new ModalLike(R.drawable.legasy_like1, "legasy"));

        adapterLike = new AdapterLike(listlike, this);
        like_recycler.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        like_recycler.setAdapter(adapterLike);

    }


    private void listiner() {


    }

    @Override
    public void onClick(View view) {

    }
}