package com.example.startupbundle.Fragmernts.ProfileFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.startupbundle.Activity.HomeActivity.HomeActivity;
import com.example.startupbundle.Fragmernts.EditProfileFragment.EditProfileFragment;
import com.example.startupbundle.Fragmernts.NotificationFragment.NotificationFragment;
import com.example.startupbundle.R;

public class ProfileFragment extends Fragment implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    private View view;
    private TextView txt_firstName,txt_gender,txt_school,txt_dob;
    private LinearLayout right_arrow_edit_profile_fragment;
    private ImageView img_notification, img_editProfile;
    private String value;
    private Spinner et_gender;
    private String[] gender_ed = {"Male", "Female", "Other"};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_profile, container, false);
        inti();
        listiner();

        HomeActivity.txt_HeadingName.setText("Profile");
        Bundle bundle = getArguments();
        if (value!=null){
            value = bundle.getString("role");
            String name=bundle.getString("fullName");
            String email=bundle.getString("email");
            String password=bundle.getString("changePassword");
            String confirm_pass=bundle.getString("confirm_pass");
            String moblie=bundle.getString("mobile");

        }


        return view;
    }

    private void inti() {
        right_arrow_edit_profile_fragment = view.findViewById(R.id.right_arrow_edit_profile_fragment);
        img_editProfile = view.findViewById(R.id.img_editProfile);


    }

    private void listiner() {
        right_arrow_edit_profile_fragment.setOnClickListener(this);
        img_editProfile.setOnClickListener(this);



    }

    @Override
    public void onClick(View view) {
        if (view == right_arrow_edit_profile_fragment) {
            EditProfileFragment editprofile_fragment = new EditProfileFragment();
            Bundle bundle = new Bundle();
            bundle.putString("role", value);
            editprofile_fragment.setArguments(bundle);
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, editprofile_fragment).addToBackStack(null).commit();
        } else if (view == img_editProfile) {

        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}