package com.example.startupbundle.Adapter.Viewpager_like;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;


import com.example.startupbundle.Fragmernts.LikeFragment.LikeFragment;
import com.example.startupbundle.R;

import java.util.List;

public class ViewPagerAdapter_like extends PagerAdapter {


    List<Integer> list_like;

    public ViewPagerAdapter_like(List<Integer> list) {
        this.list_like = list;
    }

    @Override
    public int getCount() {
        return list_like.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view==object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view=LayoutInflater.from(container.getContext()).inflate(R.layout.viewpager_like,container,false);
        ImageView image=view.findViewById(R.id.viewpager_img_like);
        container.addView(view);
        image.setImageResource(list_like.get(position));
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }
}

