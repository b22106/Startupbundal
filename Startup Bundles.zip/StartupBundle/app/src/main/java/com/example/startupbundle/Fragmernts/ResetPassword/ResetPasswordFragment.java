package com.example.startupbundle.Fragmernts.ResetPassword;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.startupbundle.Activity.HomeActivity.HomeActivity;
import com.example.startupbundle.Fragmernts.ForgetPassword.ForgetPasswordFragment;
import com.example.startupbundle.Fragmernts.LoginFragment.LoginFragment;
import com.example.startupbundle.Fragmernts.OtpFragment.OtpFragment;
import com.example.startupbundle.Fragmernts.ProfileFragment.ProfileFragment;
import com.example.startupbundle.R;


public class ResetPasswordFragment extends Fragment implements View.OnClickListener {
    private ImageView img_pass_show;
    private ImageView img_back;
    private ImageView img_con_pass_show;
    private boolean flag = true;
    private View view;
    private Button resetSubmitBtn;
    private EditText et_newPassword, et_conNewPassword;
    private String value, value2;
    private String password, confirmpassword;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_reset_password, container, false);
        inti();
        listiner();
        Bundle bundle = getArguments();
        if (bundle != null) {
            value = bundle.getString("role");
            value2 = bundle.getString("role2");

        }

        return view;
    }

    private void inti() {
        img_con_pass_show = view.findViewById(R.id.img_con_pass_show);
        img_pass_show = view.findViewById(R.id.img_pass_show);
        resetSubmitBtn = view.findViewById(R.id.resetSubmitBtn);
        et_newPassword = view.findViewById(R.id.et_newPassword);
        et_conNewPassword = view.findViewById(R.id.et_conNewPassword);
        img_back = view.findViewById(R.id.img_back);
    }

    private void listiner() {
        resetSubmitBtn.setOnClickListener(this);
        img_pass_show.setOnClickListener(this);
        img_con_pass_show.setOnClickListener(this);
        et_newPassword.setOnClickListener(this);
        et_conNewPassword.setOnClickListener(this);
        img_back.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if (view == resetSubmitBtn) {
            password = et_newPassword.getText().toString().trim();
            confirmpassword = et_conNewPassword.getText().toString().trim();
            if (password.isEmpty()) {
                et_newPassword.setError("Fill the password");
            } else if (confirmpassword.isEmpty()) {
                et_conNewPassword.setError("not match");
            } else if (password.equals(confirmpassword)) {

                Intent intent = new Intent(getActivity(), HomeActivity.class);
                startActivity(intent);
//                LoginFragment loginFragment = new LoginFragment();
//                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
//                transaction.replace(R.id.mainContainer, loginFragment);
//                transaction.commit();
            }

        } else if (view == img_pass_show) {
            if (flag) {
                et_newPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                img_pass_show.setImageResource(R.drawable.eye_show);
                et_newPassword.setSelection(et_newPassword.getText().length());
            } else {
                et_newPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

                img_pass_show.setImageResource(R.drawable.eyehide);
                et_newPassword.setSelection(et_newPassword.getText().length());
            }
            flag = !flag;
        } else if (view == img_con_pass_show) {
            if (flag) {
                et_conNewPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                img_con_pass_show.setImageResource(R.drawable.eye_show);
                et_conNewPassword.setSelection(et_conNewPassword.getText().length());
            } else {
                et_conNewPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

                img_con_pass_show.setImageResource(R.drawable.eyehide);
                et_conNewPassword.setSelection(et_conNewPassword.getText().length());
            }
            flag = !flag;
        } else if (view == img_back) {
                Intent intent = new Intent(getActivity(), HomeActivity.class);
                intent.putExtra("resetfragment","resetfragment");
                startActivity(intent);


        }

        }

}

