package com.example.startupbundle.Activity.LoginActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.FrameLayout;

import com.example.startupbundle.Fragmernts.LoginFragment.LoginFragment;
import com.example.startupbundle.Fragmernts.OtpFragment.OtpFragment;
import com.example.startupbundle.Fragmernts.ResetPassword.ResetPasswordFragment;
import com.example.startupbundle.Fragmernts.SignUpFragment.SignUpFragment;
import com.example.startupbundle.R;

public class LoginActivity extends AppCompatActivity {
    private Activity activity;
    private FrameLayout mainContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportFragmentManager().beginTransaction().add(R.id.mainContainer, new LoginFragment()).commit();

    }

//    @Override
//    public void onBackPressed() {
//
//        int count = getSupportFragmentManager().getBackStackEntryCount();
//
//        if (count == 0) {
//            super.onBackPressed();
//            finish();
//        } else {
//            getSupportFragmentManager().popBackStack();
//
//        }

    }
//        @Override
//        public void onBackPressed() {
//            super.onBackPressed();
//            finish();
//    }
