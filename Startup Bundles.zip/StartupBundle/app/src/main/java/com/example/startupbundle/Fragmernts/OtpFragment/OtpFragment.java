package com.example.startupbundle.Fragmernts.OtpFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.startupbundle.Fragmernts.LoginFragment.LoginFragment;
import com.example.startupbundle.Fragmernts.ForgetPassword.ForgetPasswordFragment;
import com.example.startupbundle.Fragmernts.ResetPassword.ResetPasswordFragment;
import com.example.startupbundle.R;

import in.aabhasjindal.otptextview.OTPListener;
import in.aabhasjindal.otptextview.OtpTextView;


public class OtpFragment extends Fragment implements View.OnClickListener, OTPListener {
    private OtpTextView otp_view;
    private View view;
    private TextView tv_email, tv_resendOtp;
    private ImageView img_back;
    private Button otpSubmitBtn;
    String value;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_otp, container, false);

        inti();
        listiner();

        return view;
    }

    private void inti() {
        tv_email = view.findViewById(R.id.tv_email);
        tv_resendOtp = view.findViewById(R.id.tv_resendOtp);
        img_back = view.findViewById(R.id.img_back);
        otpSubmitBtn = view.findViewById(R.id.otpSubmitBtn);
        otp_view = view.findViewById(R.id.otp_view);


    }

    private void listiner() {
        otpSubmitBtn.setOnClickListener(this);
        img_back.setOnClickListener(this);
        tv_resendOtp.setOnClickListener(this);
        otp_view.setOtpListener(this);
        Bundle bundle = getArguments();
        String email = bundle.getString("key");
        value=bundle.getString("role");
        tv_email.setText(email);
    }

    @Override
    public void onClick(View view) {
        if (view == otpSubmitBtn) {
//            ResetPasswordFragment resetPasswordFragment = new ResetPasswordFragment();
//            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
//            transaction.replace(R.id.mainContainer, resetPasswordFragment);
//            transaction.commit();

            ResetPasswordFragment resetPasswordFragment = new ResetPasswordFragment();
            Bundle bundle = new Bundle();
            bundle.putString("role",value);
            resetPasswordFragment.setArguments(bundle);
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.mainContainer, resetPasswordFragment).commit();
        } else if (view == img_back) {
            ForgetPasswordFragment forgetPasswordFragment = new ForgetPasswordFragment();
            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.mainContainer, forgetPasswordFragment);
            transaction.commit();

//            ForgetPasswordFragment forgotPasswordFragment = new ForgetPasswordFragment();
//            Bundle bundle = new Bundle();
//            forgotPasswordFragment.setArguments(bundle);
//            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.mainContainer, forgotPasswordFragment).addToBackStack(null).commit();

        } else if (view == tv_resendOtp) {
//            ResetPasswordFragment resetPasswordFragment = new ResetPasswordFragment();
//            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
//            transaction.replace(R.id.mainContainer, resetPasswordFragment);
//            transaction.commit();

//            ResetPasswordFragment resetPasswordFragment = new ResetPasswordFragment();
//            Bundle bundle = new Bundle();
//            resetPasswordFragment.setArguments(bundle);
//            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.mainContainer, resetPasswordFragment).addToBackStack(null).commit();
        }
    }

    @Override
    public void onInteractionListener() {

    }

    @Override
    public void onOTPComplete(String otp) {

    }
}