package com.example.startupbundle.Fragmernts.NotificationFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.startupbundle.Adapter.RvNotificationsAdapter.RvNotificationsAdapter;
import com.example.startupbundle.Fragmernts.HomeFragment.HomeFragment;
import com.example.startupbundle.Fragmernts.ProfileFragment.ProfileFragment;
import com.example.startupbundle.Modal.RvNotificationsModelData;
import com.example.startupbundle.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;


public class NotificationFragment extends Fragment implements View.OnClickListener {
    View view;
    private ImageView img_back_notification;
    private RecyclerView rv_notifications;
    private ArrayList<RvNotificationsModelData> data;
    private RvNotificationsAdapter adapter;
    private String value;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_notification, container, false);
        inti();
        listiner();
        Bundle bundle = getArguments();
        value = bundle.getString("role");

        data = new ArrayList<>();
        data.add(new RvNotificationsModelData("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.", "11:30 AM"));
        data.add(new RvNotificationsModelData("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.", "11:30 AM"));
        data.add(new RvNotificationsModelData("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.", "11:30 AM"));
        data.add(new RvNotificationsModelData("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.", "11:30 AM"));
        data.add(new RvNotificationsModelData("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.", "11:30 AM"));
        data.add(new RvNotificationsModelData("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.", "11:30 AM"));
        data.add(new RvNotificationsModelData("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.", "11:30 AM"));
        data.add(new RvNotificationsModelData("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.", "11:30 AM"));
        data.add(new RvNotificationsModelData("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.", "11:30 AM"));
        data.add(new RvNotificationsModelData("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.", "11:30 AM"));


        adapter = new RvNotificationsAdapter(getContext(), data);
        rv_notifications.setHasFixedSize(true);
        rv_notifications.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        rv_notifications.setAdapter(adapter);
        return view;
    }

    private void inti() {
        img_back_notification = view.findViewById(R.id.img_back_notification);
        rv_notifications = view.findViewById(R.id.rv_notifications);


    }

    private void listiner() {
        img_back_notification.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view == img_back_notification) {
            HomeFragment homeFragment = new HomeFragment();
            Bundle bundle = new Bundle();
            bundle.putString("role", value);
            homeFragment.setArguments(bundle);
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.homeContainer, homeFragment).commit();

        }
    }


}

